# Privacy Policy

No information is used or shared. Your data is safe.
